%% CMSC 426: Project 5 Helper Code
% Written by: Nitin J. Sanket (nitinsan@terpmail.umd.edu)
% PhD in CS Student at University of Maryland, College Park
% Acknowledgements: Bhoram Lee of University of Pennsylvania for help with depthToCloud function

clc
clear all
close all

%% Setup Paths and Read RGB and Depth Images
Path = '../Data/SingleObject/'; 
SceneNum = 1;
SceneName = sprintf('%0.3d', SceneNum);
FrameNum = num2str(1);

I = imread([Path,'scene_',SceneName,'/frames/image_',FrameNum,'_rgb.png']);
ID = imread([Path,'scene_',SceneName,'/frames/image_',FrameNum,'_depth.png']);
% I = cutOuterEdges(I,.2);
ID = cutOuterEdges(ID,.2);

%% Extract 3D Point cloud
% Inputs:
% ID - the depth image
% I - the RGB image
% calib_file - calibration data path (.mat) 
%              ex) './param/calib_xtion.mat'
%              
% Outputs:
% pcx, pcy, pcz    - point cloud (valid points only, in RGB camera coordinate frame)
% r,g,b            - color of {pcx, pcy, pcz}
% D_               - registered z image (NaN for invalid pixel) 
% X,Y              - registered x and y image (NaN for invalid pixel)
% validInd	   - indices of pixels that are not NaN or zero
% NOTE:
% - pcz equals to D_(validInd)
% - pcx equals to X(validInd)
% - pcy equals to Y(validInd)

[pcx, pcy, pcz, r, g, b, D_, X, Y,validInd] = depthToCloud_full_RGB(ID, I, './params/calib_xtion.mat');
Pts = [pcx pcy pcz];

%% Display Images and 3D Points
% Note this needs the computer vision toolbox: you'll have to run this on
% the server
% figure,
% subplot 121
% imshow(I);
% title('RGB Input Image');
% subplot 122
% imagesc(ID);
% title('Depth Input Image');

% figure,
% pcshow(Pts,[r g b]/255);
% drawnow;
% title('3D Point Cloud');

[pcX,pcY,pcZ,R,G,B] = cleanPointCloud(pcx,pcy,pcz,r,g,b);
Pts = [pcX pcY pcZ];
figure,
pcshow(Pts,[R G B]/255);
drawnow;
title('3D Point Cloud');

